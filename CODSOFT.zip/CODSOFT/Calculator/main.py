# import tkinter as tk 


# calculation = ""

# def add_to_calculation(symbol):
#     global calculation
#     calculation += str(symbol)
#     text_result.delete(1.0, "end")
#     text_result.insert(1.0, calculation)


# def evaluate_calculation():
#     global calculation
    
#     try:
        
#         calculation = str(eval(calculation))
        
#         text_result.delete(1.0, "end")
#         text_result.insert(1.0, calculation)


#     except:
#         clear_field()
#         text_result.insert(1.0, "Error")
        

# def clear_field():
#     global calculation
#     calculation = ""
#     text_result.delete(1.0, "end")
    



# root = tk.Tk()
# root.geometry("300x275")
# text_result = tk.Text(root, height=2, width=16, font=("Arial", 24))
# text_result.grid(columnspan=20)


# btn_1 = tk.Button(root, text="1", command=lambda: add_to_calculation(1), width=6, font=("Arial", 15))
# btn_1.grid(row=2, column=1)
# btn_2 = tk.Button(root, text="2", command=lambda: add_to_calculation(2), width=6, font=("Arial", 15))
# btn_2.grid(row=2, column=2)
# btn_3 = tk.Button(root, text="3", command=lambda: add_to_calculation(3), width=6, font=("Arial", 15))
# btn_3.grid(row=2, column=3)
# btn_4 = tk.Button(root, text="4", command=lambda: add_to_calculation(4), width=6, font=("Arial", 15))
# btn_4.grid(row=3, column=1)
# btn_5 = tk.Button(root, text="5", command=lambda: add_to_calculation(5), width=6, font=("Arial", 15))
# btn_5.grid(row=3, column=2)
# btn_6 = tk.Button(root, text="6", command=lambda: add_to_calculation(6), width=6, font=("Arial", 15))
# btn_6.grid(row=3, column=3)
# btn_7 = tk.Button(root, text="7", command=lambda: add_to_calculation(7), width=6, font=("Arial", 15))
# btn_7.grid(row=4, column=1)
# btn_8 = tk.Button(root, text="8", command=lambda: add_to_calculation(8), width=6, font=("Arial", 15))
# btn_8.grid(row=4, column=2)
# btn_9 = tk.Button(root, text="9", command=lambda: add_to_calculation(9), width=6, font=("Arial", 15))
# btn_9.grid(row=4, column=3)
# btn_0 = tk.Button(root, text="0", command=lambda: add_to_calculation(0), width=6, font=("Arial", 15))
# btn_0.grid(row=5, column=2)
# btn_plus = tk.Button(root, text="+", command=lambda: add_to_calculation("+"), width=6, font=("Arial", 15))
# btn_plus.grid(row=2, column=4)
# btn_minus = tk.Button(root, text="-", command=lambda: add_to_calculation("-"), width=6, font=("Arial", 15))
# btn_minus.grid(row=3, column=4)
# btn_mul = tk.Button(root, text="x", command=lambda: add_to_calculation("x"), width=6, font=("Arial", 15))
# btn_mul.grid(row=4, column=4)
# btn_div = tk.Button(root, text="/", command=lambda: add_to_calculation("/"), width=6, font=("Arial", 15))
# btn_div.grid(row=5, column=4)
# btn_open = tk.Button(root, text="(", command=lambda: add_to_calculation("("), width=6, font=("Arial", 15))
# btn_open.grid(row=5, column=1)
# btn_close = tk.Button(root, text=")", command=lambda: add_to_calculation(")"), width=6, font=("Arial", 15))
# btn_close.grid(row=5, column=3)
# btn_clear = tk.Button(root, text="C", command=clear_field, width=12, font=("Arial", 15))
# btn_clear.grid(row=6, column=1, columnspan=2)
# btn_equals = tk.Button(root, text="=", command= evaluate_calculation, width=12, font=("Arial", 15))
# btn_equals.grid(row=6, column=3, columnspan=2)
# root.mainloop()






# from tkinter import *

# def button_press(num):

#     global equation_text

#     equation_text = equation_text + str(num)

#     equation_label.set(equation_text)

# def equals():

#     global equation_text

#     try:

#         total = str(eval(equation_text))

#         equation_label.set(total)

#         equation_text = total

#     except SyntaxError:

#         equation_label.set("Syntax Error")

#         equation_text = ""

#     except ZeroDivisionError:

#         equation_label.set("Arithmetic Error")

#         equation_text = ""

# def clear():

#     global equation_text

#     equation_label.set("")

#     equation_text = ""


# window = Tk()
# window.title("Calculator")
# window.geometry("500x500")

# equation_text = ""

# equation_label = StringVar()

# label = Label(window, textvariable=equation_label, font=('consolas',20), bg="white", width=24, height=2)
# label.pack()

# frame = Frame(window)
# frame.pack()

# button1 = Button(frame, text=1, height=4, width=9, font=35,
#                  command=lambda: button_press(1))
# button1.grid(row=0, column=0)

# button2 = Button(frame, text=2, height=4, width=9, font=35,
#                  command=lambda: button_press(2))
# button2.grid(row=0, column=1)

# button3 = Button(frame, text=3, height=4, width=9, font=35,
#                  command=lambda: button_press(3))
# button3.grid(row=0, column=2)

# button4 = Button(frame, text=4, height=4, width=9, font=35,
#                  command=lambda: button_press(4))
# button4.grid(row=1, column=0)

# button5 = Button(frame, text=5, height=4, width=9, font=35,
#                  command=lambda: button_press(5))
# button5.grid(row=1, column=1)

# button6 = Button(frame, text=6, height=4, width=9, font=35,
#                  command=lambda: button_press(6))
# button6.grid(row=1, column=2)

# button7 = Button(frame, text=7, height=4, width=9, font=35,
#                  command=lambda: button_press(7))
# button7.grid(row=2, column=0)

# button8 = Button(frame, text=8, height=4, width=9, font=35,
#                  command=lambda: button_press(8))
# button8.grid(row=2, column=1)

# button9 = Button(frame, text=9, height=4, width=9, font=35,
#                  command=lambda: button_press(9))
# button9.grid(row=2, column=2)

# button0 = Button(frame, text=0, height=4, width=9, font=35,
#                  command=lambda: button_press(0))
# button0.grid(row=3, column=0)

# plus = Button(frame, text='+', height=4, width=9, font=35,
#                  command=lambda: button_press('+'))
# plus.grid(row=0, column=3)

# minus = Button(frame, text='-', height=4, width=9, font=35,
#                  command=lambda: button_press('-'))
# minus.grid(row=1, column=3)

# multiply = Button(frame, text='x', height=4, width=9, font=35,
#                  command=lambda: button_press('x'))
# multiply.grid(row=2, column=3)

# divide = Button(frame, text='/', height=4, width=9, font=35,
#                  command=lambda: button_press('/'))
# divide.grid(row=3, column=3)

# equal = Button(frame, text='=', height=4, width=9, font=35,
#                  command=equals)
# equal.grid(row=3, column=2)

# decimal = Button(frame, text='.', height=4, width=9, font=35,
#                  command=lambda: button_press('.'))
# decimal.grid(row=3, column=1)

# clear = Button(window, text='clear', height=4, width=12, font=35,
#                  command=clear)
# clear.pack()

# window.mainloop()






import tkinter as tk

# Function to evaluate the expression
def evaluate_expression():
    try:
        result.set(eval(expression.get()))
    except:
        result.set("Error")

# Function to clear the input field
def clear():
    expression.set("")
    result.set("")

# Create the main window
root = tk.Tk()
root.title("Calculator")

# Variables to store expression and result
expression = tk.StringVar()
result = tk.StringVar()

# Entry widget to display the expression
entry = tk.Entry(root, textvariable=expression, bd=5)
entry.grid(row=0, column=0, columnspan=4)

# Button widgets for numbers and operations
buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', 'x',
    '1', '2', '3', '-',
    'C', '0', '=', '+'
]

# Function to add button click event
def on_button_click(key):
    if key == '=':
        evaluate_expression()
    elif key == 'C':
        clear()
    else:
        expression.set(expression.get() + key)

row = 1
col = 0
for button in buttons:
    tk.Button(root, text=button, width=5, command=lambda b=button: on_button_click(b)).grid(row=row, column=col)
    col += 1
    if col > 3:
        col = 0
        row += 1

# Entry widget to display the result
result_label = tk.Label(root, textvariable=result)
result_label.grid(row=row, column=0, columnspan=4)

root.mainloop()
