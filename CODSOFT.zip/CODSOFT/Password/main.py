# importing modules
import string
import random


# storing all the characters in lists 
s1 = list(string.ascii_lowercase)
s2 = list(string.ascii_uppercase)
s3 = list(string.digits)
s4 = list(string.punctuation)


# Asking user about the length of characters
user_input = input("Enter number of characters you want in your password: ")


# checking if the input is number or is it more than 8?
while True:

	try:

		characters_number = int(user_input)

		if characters_number < 8:

			print("Input should be at least greater than or equal to 8.")

			user_input = input("Sorry, Please enter again: ")

		else:

			break

	except:

		print(" Enter positive integer only.")

		user_input = input("Enter number of characters you want in your password: ")


# shuffling all the lists
random.shuffle(s1)
random.shuffle(s2)
random.shuffle(s3)
random.shuffle(s4)


# calculating the input 
part1 = round(characters_number * (30/100))
part2 = round(characters_number * (20/100))


# generation of the password 
result = []

for a in range(part1):

	result.append(s1[a])
	result.append(s2[a])

for a in range(part2):

	result.append(s3[a])
	result.append(s4[a])


# shuffling the result
random.shuffle(result)


# joining result
password = "".join(result)
print("Generated Password: ", password)
